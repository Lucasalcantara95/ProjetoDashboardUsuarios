﻿namespace Globo.Suave.Dashboard.SGP.Dominio;

public class UserInfo
{
    public string Email { get; set; }
    public string ProfileName { get; set; }
    public int? ProgramId { get; set; }
    public string ProgramName { get; set; }
    public int? ActorId { get; set; }
    public int? UserId { get; set; }
    public string UserLogin { get; set; }
    public string ActorName {get; set;}
    public string CharInfo {get; set;}
    public string AppName{get; set;}
}

  public class ActorInfo
    {
        public int? ProgramId { get; set; }
        public int? ActorId { get;  set; }
        public string? ActorName { get; set; }
        public string? Character { get; set; }
    }