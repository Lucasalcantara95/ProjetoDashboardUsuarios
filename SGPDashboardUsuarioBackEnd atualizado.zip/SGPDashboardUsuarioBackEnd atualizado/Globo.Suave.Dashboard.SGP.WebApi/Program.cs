using Globo.Suave.Dashboard.SGP.Dominio;
using Globo.Suave.Dashboard.SGP.Infra;

var builder = WebApplication.CreateBuilder(args);
string connectionStringSGP = Environment.GetEnvironmentVariable("CONNECTION_STRING_SGP");
string connectionStringEVA = Environment.GetEnvironmentVariable("CONNECTION_STRING_EVA");
string connectionStringSEMPRE = Environment.GetEnvironmentVariable("CONNECTION_STRING_SEMPRE");
// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.MapGet("/dashboard/eva/usuarios/{usuario}", (string usuario) =>
{
    var dataAccess = new DataAccess(connectionStringEVA);
    List<UserInfo> userInfos = dataAccess.RetornoUsuarioComAlocacao(usuario);
    return userInfos;
})
.WithName("GetUsuarioComAlocacao")
.WithOpenApi();


app.MapGet("/dashboard/sgp/usuarios/{usuario}", (int actorInfo, int ProgramId) =>
{ 
    
    var dataAccess = new DataAccess(connectionStringSGP);
    List<UserInfo> userInfos = dataAccess.GetActorInformation(actorInfo, ProgramId);
    return userInfos;
})
.WithName("GetActorInformation")
.WithOpenApi();

app.MapGet("/dashboard/sempre/usuarios", (string usuario) =>
{
   var dataAccess = new DataAccess(connectionStringSEMPRE);
   List<UserInfo> userInfos = dataAccess.RetornoInfoUsuario(usuario);
   return userInfos;
})
.WithName("RetornoInfoUsuario")
.WithOpenApi();


app.MapPost("/auth/token", (string usuario) =>
{
  return "";

})
.WithName("AccountConnectGerarToken")
.WithOpenApi();


app.MapPost("/auth/refreshtoken", (string usuario) =>
{
  return "";

})
.WithName("AccountConnectGerarToken")
.WithOpenApi();

app.Run();
