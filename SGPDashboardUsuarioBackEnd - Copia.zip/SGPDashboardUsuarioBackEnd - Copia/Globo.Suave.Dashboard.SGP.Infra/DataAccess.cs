﻿using Globo.Suave.Dashboard.SGP.Dominio;
using MySql.Data.MySqlClient;

namespace Globo.Suave.Dashboard.SGP.Infra;

public class DataAccess
{
 private readonly string connectionString;

    public DataAccess(string connectionString)
    {
        this.connectionString = connectionString;
    }

    public List<UserInfo> GetActorInformation(int actorInfo, int ProgramId)
    {
        List<UserInfo> userInfoList = new List<UserInfo>();

        using (MySqlConnection connection = new MySqlConnection(connectionString))
    
        {
            string query= @"
                SELECT tp.id_programa AS ProgramId, 
                        tp.id_ator AS ActorId, 
                        ta.nm_ator AS ActorName,
                        tp.nm_personagem AS CharInfo
                FROM TB_PERSONAGEM tp
                INNER JOIN TB_ATOR ta ON ta.id = tp.id_ator
                WHERE tp.id_programa = @ProgramId AND tp.id_ator= @ActorId";

            MySqlCommand command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@ActorId", actorInfo);
            command.Parameters.AddWithValue("@ProgramId", ProgramId);

            connection.Open();

            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    UserInfo userInfo = new UserInfo
                    {
                        ProgramId = reader["ProgramId"] != DBNull.Value ? Convert.ToInt32(reader["ProgramId"]) : (int?)null,
                        ActorId = reader["ActorId"] != DBNull.Value ? Convert.ToInt32(reader["ActorId"]) : (int?)null,
                        ActorName = reader["ActorName"].ToString(),
                        CharInfo = reader["CharInfo"].ToString()
                    };
                    userInfoList.Add(userInfo);
                }
            }
        }

        return userInfoList;
    }
    public List<UserInfo> RetornoTodosUsuariosComAlocacao()
    {
        List<UserInfo> userInfoList = new List<UserInfo>();

        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query= @"
                SELECT
                        usu.id IdUsuario,
                        usu.ds_nome nomeUsuario,
                        usu.ds_email emailUsuario,
                        usu.id_ator idAtor,
                        usu.nm_login loginUsuario,
                        usu.nm_perfil perfilUsuario,
                        tup.id_produto idProduto, 
                        tp.ds_nome nomeProduto
                FROM
                        tb_usuario usu
                        LEFT JOIN tb_usuario_produto tup ON
                        usu.id = tup.id_usuario
                LEFT JOIN tb_produto tp ON tup.id_produto = tp.id
                ORDER BY
                        usu.ds_nome";




            MySqlCommand command = new MySqlCommand(query, connection);

            connection.Open();

            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    UserInfo userInfo = new UserInfo
                    {
                        Email = reader["emailUsuario"].ToString(),
                        ProfileName = reader["perfilUsuario"].ToString(),
                        ProgramId = reader["idProduto"] != DBNull.Value ? Convert.ToInt32(reader["idProduto"]) : (int?)null,
                        ProgramName = reader["nomeProduto"].ToString(),
                        ActorId = reader["idAtor"] != DBNull.Value ? Convert.ToInt32(reader["idAtor"]) : (int?)null,
                        UserId = reader["IdUsuario"] != DBNull.Value ? Convert.ToInt32(reader["IdUsuario"]) : (int?)null,
                        UserLogin = reader["loginUsuario"].ToString(),
            
                    };
                    userInfoList.Add(userInfo);
                }
                
            }
        }

        return userInfoList;
    }
      public List<UserInfo> RetornoUsuarioComAlocacao(string email)
    {
        List<UserInfo> userInfoList = new List<UserInfo>();

        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query= @"
                        SELECT 
                            usu.id IdUsuario,
                            usu.ds_nome,
                            usu.ds_email emailUsuario,
                            usu.id_ator idAtor,
                            usu.nm_login loginUsuario,
                            usu.nm_perfil perfilUsuario,
                            tup.id_produto idProduto,
                            tp.ds_nome nomeProduto
                        FROM
                            tb_usuario usu
                        LEFT JOIN tb_usuario_produto tup ON
                            usu.id = tup.id_usuario
                        LEFT JOIN tb_produto tp ON tup.id_produto = tp.id
                        WHERE usu.ds_email = @Email";





            MySqlCommand command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@Email", email);
            connection.Open();

            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    UserInfo userInfo = new UserInfo
                    {
                        Email = reader["emailUsuario"].ToString(),
                        ProfileName = reader["perfilUsuario"].ToString(),
                        ProgramId = reader["idProduto"] != DBNull.Value ? Convert.ToInt32(reader["idProduto"]) : (int?)null,
                        ProgramName = reader["nomeProduto"].ToString(),
                        ActorId = reader["idAtor"] != DBNull.Value ? Convert.ToInt32(reader["idAtor"]) : (int?)null,
                        UserId = reader["IdUsuario"] != DBNull.Value ? Convert.ToInt32(reader["IdUsuario"]) : (int?)null,
                        UserLogin = reader["loginUsuario"].ToString(),
            
                    };
                    userInfoList.Add(userInfo);
                }
                
            }
        }

        return userInfoList;
    }
           public List<UserInfo> RetornoInfoUsuario(string email)
    {
        List<UserInfo> userInfoList = new List<UserInfo>();

        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query= @"
                    SELECT tu.id AS UserId, tu.nm_login AS Email, tp.ds_perfil AS ProfileName FROM TB_USUARIO tu
                        INNER JOIN TB_USUARIO_PERFIL tup ON tup.id_usuario = tu.id
                        INNER JOIN TB_PERFIL tp ON tup.id_perfil = tp.id AND tp.id_aplicacao = 6
                        WHERE tu.nm_login = @Email";



            MySqlCommand command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@Email", email);

            connection.Open();

            using (MySqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    UserInfo userInfo = new UserInfo
                    {
                    
                        ProfileName = reader["ProfileName"] != DBNull.Value ? Convert.ToString(reader["ProfileName"]) : (string?)null,
                        Email = reader["Email"] != DBNull.Value ? Convert.ToString(reader["Email"]) : (string?)null,
                        UserId = reader["UserId"] != DBNull.Value ? Convert.ToInt32(reader["UserId"]) : (int?)null,
                        
                    };
                    userInfoList.Add(userInfo);
                }
                
            }
        }

        return userInfoList;

    }

}