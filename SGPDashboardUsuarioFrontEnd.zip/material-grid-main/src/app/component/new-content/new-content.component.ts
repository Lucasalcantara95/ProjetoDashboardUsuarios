import { Component } from '@angular/core';

@Component({
  selector: 'app-new-content',
  standalone: true,
  imports: [],
  templateUrl: './new-content.component.html',
  styleUrl: './new-content.component.scss'
})
export class NewContentComponent {

}
