export class sempre {
    perfil: string;

    constructor(perfis: string) {
        this.perfil = perfis;
    }
}