export enum Apllication {
    SEMPRE = 'sempre',
    SGP = 'sgp',
    EVA = 'eva',
    HOME = 'home',
}
